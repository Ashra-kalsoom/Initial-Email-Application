import bootApp from "boot.jsx";
import LicenseApp from "components/license/LicenseApp.jsx";

bootApp(LicenseApp, "license");
