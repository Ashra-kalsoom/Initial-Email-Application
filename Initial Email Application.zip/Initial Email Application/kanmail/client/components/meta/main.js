import bootApp from "boot.jsx";
import MetaApp from "components/meta/MetaApp.jsx";

bootApp(MetaApp, "meta");
