import bootApp from "boot.jsx";
import EmailsApp from "components/emails/EmailsApp.jsx";

bootApp(EmailsApp, "emails");
